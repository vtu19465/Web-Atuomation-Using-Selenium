from process import process
from connect import connect
def main():

    process(connect())

main()